<?php

namespace block_learnerscript\Spout\Common\Exception;

/**
 * Class EncodingConversionException
 *
 * @api
 * @package block_learnerscript\Spout\Common\Exception
 */
class EncodingConversionException extends SpoutException
{
}
