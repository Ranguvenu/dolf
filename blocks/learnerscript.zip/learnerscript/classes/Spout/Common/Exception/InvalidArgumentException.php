<?php

namespace block_learnerscript\Spout\Common\Exception;

/**
 * Class InvalidArgumentException
 *
 * @api
 * @package block_learnerscript\Spout\Common\Exception
 */
class InvalidArgumentException extends SpoutException
{
}
