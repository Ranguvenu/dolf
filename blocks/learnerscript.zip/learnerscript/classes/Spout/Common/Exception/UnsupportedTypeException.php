<?php

namespace block_learnerscript\Spout\Common\Exception;

/**
 * Class UnsupportedTypeException
 *
 * @api
 * @package block_learnerscript\Spout\Common\Exception
 */
class UnsupportedTypeException extends SpoutException
{
}
