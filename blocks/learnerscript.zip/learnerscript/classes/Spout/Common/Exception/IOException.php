<?php

namespace block_learnerscript\Spout\Common\Exception;

/**
 * Class IOException
 *
 * @api
 * @package block_learnerscript\Spout\Common\Exception
 */
class IOException extends SpoutException
{
}
