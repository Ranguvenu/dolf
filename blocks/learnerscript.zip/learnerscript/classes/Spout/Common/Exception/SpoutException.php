<?php

namespace block_learnerscript\Spout\Common\Exception;

/**
 * Class SpoutException
 *
 * @package block_learnerscript\Spout\Common\Exception
 * @abstract
 */
abstract class SpoutException extends \Exception
{
}
