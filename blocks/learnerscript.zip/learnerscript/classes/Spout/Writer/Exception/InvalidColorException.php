<?php

namespace block_learnerscript\Spout\Writer\Exception;

/**
 * Class InvalidColorException
 *
 * @api
 * @package block_learnerscript\Spout\Writer\Exception
 */
class InvalidColorException extends WriterException
{
}
