<?php

namespace block_learnerscript\Spout\Writer\Exception;

/**
 * Class WriterAlreadyOpenedException
 *
 * @api
 * @package block_learnerscript\Spout\Writer\Exception
 */
class WriterAlreadyOpenedException extends WriterException
{
}
