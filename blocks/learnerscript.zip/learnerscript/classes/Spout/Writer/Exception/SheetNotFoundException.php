<?php

namespace block_learnerscript\Spout\Writer\Exception;

/**
 * Class SheetNotFoundException
 *
 * @api
 * @package block_learnerscript\Spout\Writer\Exception
 */
class SheetNotFoundException extends WriterException
{
}
