<?php

namespace block_learnerscript\Spout\Writer\Exception;

/**
 * Class WriterNotOpenedException
 *
 * @api
 * @package block_learnerscript\Spout\Writer\Exception
 */
class WriterNotOpenedException extends WriterException
{
}
