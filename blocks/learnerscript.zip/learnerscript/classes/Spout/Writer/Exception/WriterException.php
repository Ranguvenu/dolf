<?php

namespace block_learnerscript\Spout\Writer\Exception;

use block_learnerscript\Spout\Common\Exception\SpoutException;

/**
 * Class WriterException
 *
 * @package block_learnerscript\Spout\Writer\Exception
 * @abstract
 */
abstract class WriterException extends SpoutException
{
}
