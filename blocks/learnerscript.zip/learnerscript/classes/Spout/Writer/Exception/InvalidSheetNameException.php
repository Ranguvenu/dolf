<?php

namespace block_learnerscript\Spout\Writer\Exception;

/**
 * Class InvalidSheetNameException
 *
 * @api
 * @package block_learnerscript\Spout\Writer\Exception
 */
class InvalidSheetNameException extends WriterException
{
}
