<?php

namespace block_learnerscript\Spout\Reader\Exception;

/**
 * Class NoSheetsFoundException
 *
 * @api
 * @package block_learnerscript\Spout\Reader\Exception
 */
class NoSheetsFoundException extends ReaderException
{
}
