<?php

namespace block_learnerscript\Spout\Reader\Exception;

/**
 * Class SharedStringNotFoundException
 *
 * @api
 * @package block_learnerscript\Spout\Reader\Exception
 */
class SharedStringNotFoundException extends ReaderException
{
}
