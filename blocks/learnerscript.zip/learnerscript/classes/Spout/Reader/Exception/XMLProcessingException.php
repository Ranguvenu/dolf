<?php

namespace block_learnerscript\Spout\Reader\Exception;

/**
 * Class XMLProcessingException
 *
 * @package block_learnerscript\Spout\Reader\Exception
 */
class XMLProcessingException extends ReaderException
{
}
