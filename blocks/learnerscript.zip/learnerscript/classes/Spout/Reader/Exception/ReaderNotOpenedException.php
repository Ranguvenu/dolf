<?php

namespace block_learnerscript\Spout\Reader\Exception;

/**
 * Class ReaderNotOpenedException
 *
 * @api
 * @package block_learnerscript\Spout\Reader\Exception
 */
class ReaderNotOpenedException extends ReaderException
{
}
