define(function() {
    return Highcharts;
});